.. $Id: dblock.rst,v 337846be2a21 2010/09/17 14:26:06 jcea $

DBLock
------

Read `Oracle documentation
<http://download.oracle.com/docs/cd/E17076_02/html/programmer_reference/index.html>`__
for better understanding.

The DBLock objects have no methods or attributes. They are just opaque
handles to the lock in question.

They are managed via DBEnv methods.

